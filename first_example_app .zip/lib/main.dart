import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Flutter App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "UI App with Flutter",
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.search),
          ),
          IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (BuildContext context) => AlertDialog(
                          title: const Text("Ayarlar"),
                          content: const Text("Ayarlar bölümü içeriği"),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context, "Kapat");
                              },
                              child: const Text("Kapat"),
                            ),
                          ],
                        ));
              },
              icon: const Icon(Icons.settings))
        ],
        backgroundColor: Colors.pinkAccent,
      ),
      drawer: Drawer(
        child: ListView(
          children: const [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.cyan),
              child: Text(
                "Drawer Header",
                style: TextStyle(fontSize: 24),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text("Ev"),
            ),
            ListTile(
              leading: Icon(Icons.help),
              title: Text('Yardım'),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          const Text(
            "Welcome to My App!",
            style: TextStyle(
              fontSize: 25,
              color: Colors.greenAccent,
            ),
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 20.0),
                child: Column(
                  children: [
                    const Text(
                      "Widget 1",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        color: Colors.amber,
                        shape: BoxShape.circle,
                      ),
                      width: 75,
                      height: 75,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content:
                                  Text("Kapatmak için Close butonuna basın..."),
                            ),
                          );
                        },
                        child: const Text("OPEN Text Button"),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 2.0),
                child: Column(
                  children: [
                    const Text(
                      "Widget 2",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        color: Colors.amber,
                        shape: BoxShape.circle,
                      ),
                      width: 75,
                      height: 75,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).clearSnackBars();
                      },
                      child: const Text("CLOSE Text Button"),
                    ),
                  ],
                ),
              )
            ],
          ),
          const Text(
            "Açıklama",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
          ),
          const Text("Bu benim ilk mobil uygulamam...")
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
              context: context,
              builder: (BuildContext context) => AlertDialog(
                    title: const Text('AlertDialog Title'),
                    content: const Text("This is a Alert dialog..."),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context, "Kapat");
                        },
                        child: const Text("Kapat"),
                      ),
                    ],
                  ));
        },
        backgroundColor: Colors.purpleAccent,
        elevation: 20,
        autofocus: true,
        child: const Icon(Icons.add),
      ),
      backgroundColor: Colors.grey,
    );
  }
}
